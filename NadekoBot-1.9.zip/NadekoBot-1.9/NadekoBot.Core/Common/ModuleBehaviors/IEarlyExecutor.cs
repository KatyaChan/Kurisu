﻿namespace NadekoBot.Common.ModuleBehaviors
{
    public interface IEarlyExecutor
    {
        
    }
}
